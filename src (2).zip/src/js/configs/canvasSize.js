CE.width = 600;
CE.height = 450;