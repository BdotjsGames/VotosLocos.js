var DIRECTION = {
    down: 0,
    left: 1,
    up: 2,
    right: 3,
    opposite: d=> (d+2)%4
  }